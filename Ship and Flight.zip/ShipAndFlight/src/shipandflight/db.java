package shipandflight; 

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class db {

    public static Connection mycon() throws SQLException {
        try {
            System.out.println("1");
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ship_and_flight_db?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "");
            System.out.println("2");
            return con;
        } catch (ClassNotFoundException | SQLException e) {
            // Print the actual exception for debugging
            e.printStackTrace();
            throw new SQLException("Failed to connect to the database.");
        }
    }
}

    
